<?php

/**
 * Plugin Name: PL UPDATE
 * Plugin URI: 
 * Version: 1.0.0
 * Author: 
 * Author URI: 
 * License: GPL2
 */

// Exit if accessed directly.
if (! defined('ABSPATH')) {
    exit;
}

add_filter('pre_set_site_transient_update_plugins', 'update_system');

function update_system($abc)
{
    // echo '<pre>';
    // print_r($abc);
    // echo '</pre>';

    $abc->response['pl-update/pl-update.php'] = (object)[
        'slug' => 'pl-update',
        'new_version' => '1.1.0',
        'package' => 'https://example.com/my-plugin.zip',
        'url' => 'https://elementor.com/pro/changelog/'
    ];
    return $abc;
}
